package com.flyhigh.transactions;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ItauTransactionsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ItauTransactionsApplication.class, args);
	}

}
